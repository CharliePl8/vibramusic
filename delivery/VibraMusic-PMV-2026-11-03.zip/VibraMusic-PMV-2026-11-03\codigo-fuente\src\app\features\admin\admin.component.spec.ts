import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { EMPTY } from 'rxjs';
import { AdminComponent } from './admin.component';
import { AdminService } from '../../core/services/admin.service';
import { ToastService } from '../../core/services/toast.service';

const booking = {
  id: 'b1',
  userId: 'u1',
  date: '2026-10-01',
  slot: '09:00–12:00',
  service: 'Grabación',
  notes: '',
  createdAt: 0,
  studentName: 'Ana',
  studentEmail: 'ana@example.com',
};

const message = {
  id: 'm1',
  name: 'Ana',
  email: 'ana@example.com',
  message: 'Hola',
  read: false,
  createdAt: 0,
};

describe('AdminComponent', () => {
  let fixture: ComponentFixture<AdminComponent>;
  let component: AdminComponent;
  const bookings = vi.fn();
  const messages = vi.fn();
  const unreadMessages = vi.fn();
  const cancelBooking = vi.fn();
  const setMessageRead = vi.fn();
  const deleteMessage = vi.fn();
  const success = vi.fn();
  const error = vi.fn();
  const confirm = vi.fn(() => true);

  beforeEach(async () => {
    bookings.mockReset();
    messages.mockReset();
    unreadMessages.mockReset();
    cancelBooking.mockReset();
    setMessageRead.mockReset();
    deleteMessage.mockReset();
    success.mockReset();
    error.mockReset();
    confirm.mockReset();
    confirm.mockReturnValue(true);

    bookings.mockResolvedValue({ rows: [], total: 0 });
    messages.mockResolvedValue({ rows: [], total: 0 });
    unreadMessages.mockResolvedValue(0);

    vi.stubGlobal('confirm', confirm);

    await TestBed.configureTestingModule({
      imports: [AdminComponent],
      providers: [
        {
          provide: AdminService,
          useValue: {
            bookings,
            messages,
            unreadMessages,
            cancelBooking,
            setMessageRead,
            deleteMessage,
          },
        },
        { provide: ToastService, useValue: { success, error } },
        {
          provide: Router,
          useValue: {
            events: EMPTY,
            navigate: vi.fn(),
            createUrlTree: vi.fn(() => []),
            serializeUrl: vi.fn(() => '/'),
          },
        },
        { provide: ActivatedRoute, useValue: {} },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('cancela una reserva y recarga la lista', async () => {
    cancelBooking.mockResolvedValue(true);
    bookings.mockResolvedValue({ rows: [], total: 0 });

    await component.cancelBooking('b1');

    expect(cancelBooking).toHaveBeenCalledWith('b1');
    expect(bookings).toHaveBeenCalled();
    expect(component.bookings()).toEqual([]);
    expect(success).toHaveBeenCalled();
  });

  it('avisa si no se pudo cancelar', async () => {
    cancelBooking.mockResolvedValue(false);
    component.bookings.set([booking as never]);

    await component.cancelBooking('b1');

    expect(component.bookings()).toHaveLength(1);
    expect(error).toHaveBeenCalled();
  });

  it('marca un mensaje como leído y actualiza el contador', async () => {
    setMessageRead.mockResolvedValue(true);
    unreadMessages.mockResolvedValue(0);
    component.messages.set([message as never]);

    await component.toggleRead(message as never);

    expect(setMessageRead).toHaveBeenCalledWith('m1', true);
    expect(component.messages()[0].read).toBe(true);
    expect(component.unreadCount()).toBe(0);
  });

  it('distingue visualmente los mensajes leídos de los no leídos', async () => {
    const read = { ...message, read: true };
    const unread = { ...message, id: 'm2', read: false };
    component.tab.set('messages');

    fixture.detectChanges();
    component.loading.set(false);
    component.messages.set([read, unread]);
    fixture.detectChanges();

    const items = fixture.nativeElement.querySelectorAll('.admin__item') as NodeListOf<HTMLElement>;
    expect(items).toHaveLength(2);

    const [first, second] = Array.from(items);
    expect(first.classList).toContain('admin__item--read');
    expect(second.classList).toContain('admin__item--unread');
    expect(first.querySelector('.admin__status')?.textContent?.trim()).toBe('Leído');
    expect(second.querySelector('.admin__status')?.textContent?.trim()).toBe('Nuevo');
  });

  it('elimina un mensaje y recarga la lista', async () => {
    deleteMessage.mockResolvedValue(true);
    messages.mockResolvedValue({ rows: [], total: 0 });
    unreadMessages.mockResolvedValue(0);
    component.messages.set([message as never]);

    await component.deleteMessage(message as never);

    expect(deleteMessage).toHaveBeenCalledWith('m1');
    expect(component.messages()).toEqual([]);
    expect(success).toHaveBeenCalled();
  });

  it('no elimina si se cancela la confirmación', async () => {
    confirm.mockReturnValue(false);
    component.messages.set([message as never]);

    await component.deleteMessage(message as never);

    expect(deleteMessage).not.toHaveBeenCalled();
  });

  it('avanza a la página siguiente de reservas', async () => {
    bookings.mockResolvedValue({ rows: [], total: 25 });
    component.bookingTotal.set(25);

    await component.nextBookings();

    expect(component.bookingPage()).toBe(1);
    expect(bookings).toHaveBeenCalledWith(1, component.pageSize);
  });

  it('no retrocede por debajo de la primera página', async () => {
    await component.prevBookings();

    expect(component.bookingPage()).toBe(0);
  });
});
