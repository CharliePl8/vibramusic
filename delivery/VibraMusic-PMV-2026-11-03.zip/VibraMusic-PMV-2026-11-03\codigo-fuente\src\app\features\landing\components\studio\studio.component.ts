import { Component, DestroyRef, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { STUDIO_GEAR, STUDIO_IMAGE } from '../../../../core/data/studio.data';
import {
  STUDIO_SERVICES,
  STUDIO_SLOTS,
  StudioService,
  StudioSlot,
} from '../../../../core/models/booking.model';
import { BookingService } from '../../../../core/services/booking.service';
import { ToastService } from '../../../../core/services/toast.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ContactDraftService } from '../../../../core/services/contact-draft.service';

@Component({
  selector: 'app-studio',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './studio.component.html',
  styleUrl: './studio.component.scss',
})
export class StudioComponent implements OnInit {
  readonly gear = STUDIO_GEAR;
  readonly services = STUDIO_SERVICES;
  readonly slots = STUDIO_SLOTS;

  readonly bookingOpen = signal(false);
  readonly takenSlots = signal<StudioSlot[]>([]);
  readonly submitting = signal(false);

  readonly form = new FormGroup({
    date: new FormControl('', [Validators.required]),
    slot: new FormControl('', [Validators.required]),
    service: new FormControl('', [Validators.required]),
    notes: new FormControl(''),
  });

  private readonly image = STUDIO_IMAGE;

  private auth = inject(AuthService);
  private booking = inject(BookingService);
  private toast = inject(ToastService);
  private router = inject(Router);
  private destroyRef = inject(DestroyRef);
  private readonly contactDraft = inject(ContactDraftService);

  ngOnInit() {
    const handler = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash === 'booking' && !this.bookingOpen()) {
        this.openBooking();
      }
    };
    handler();
    const sub = this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe(handler);
    this.destroyRef.onDestroy(() => sub.unsubscribe());
  }

  constructor() {
    this.form.controls.date.valueChanges.subscribe((date) => {
      void this.loadTakenSlots(date);
    });
  }

  get imageStyle() {
    return { 'background-image': `url(${this.image})` };
  }

  get minDate(): string {
    return new Date().toISOString().split('T')[0];
  }

  toggleBooking() {
    if (this.bookingOpen()) {
      this.bookingOpen.set(false);
    } else {
      this.openBooking();
    }
  }

  private openBooking() {
    this.bookingOpen.set(true);
    void this.loadTakenSlots(this.form.controls.date.value);
  }

  async onSubmit() {
    const user = this.auth.currentUser();
    if (!user) {
      this.toast.info('Inicia sesión para reservar el estudio.');
      this.router.navigate(['/login']);
      return;
    }
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.error('Completa la fecha, la franja y el servicio.');
      return;
    }

    const { date, slot, service, notes } = this.form.value;
    this.submitting.set(true);
    const result = await this.booking.create({
      userId: user.id,
      date: date!,
      slot: slot as StudioSlot,
      service: service as StudioService,
      notes: notes ?? '',
    });
    this.submitting.set(false);

    if (result === 'conflict') {
      this.toast.error('Esa franja ya está reservada. Elige otra.');
      await this.loadTakenSlots(date);
      return;
    }
    if (result === 'error') {
      this.toast.error('No se pudo completar la reserva. Inténtalo de nuevo.');
      return;
    }

    this.form.reset();
    this.bookingOpen.set(false);
    this.toast.success('Reserva confirmada. La verás en tu perfil.');
  }

  isSlotAvailable(slot: string): boolean {
    return !this.takenSlots().includes(slot as StudioSlot);
  }

  requestMixingMastering(type: 'Mezcla' | 'Mastering') {
    this.contactDraft.setMessage(
      [
        `Hola, me interesa el servicio de ${type.toLowerCase()}.`,
        'Quisiera que me contactéis para hablar sobre mi proyecto, disponibilidad y presupuesto.',
        '',
        'Muchas gracias.',
      ].join('\n'),
    );
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  hasError(controlName: 'date' | 'slot' | 'service'): boolean {
    const c = this.form.get(controlName);
    return !!c && c.invalid && c.touched;
  }

  private async loadTakenSlots(date: string | null | undefined): Promise<void> {
    if (!date) {
      this.takenSlots.set([]);
      return;
    }
    this.takenSlots.set(await this.booking.takenSlots(date));
  }
}
