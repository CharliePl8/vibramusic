# Entrega — Vibra Music (PMV)

**Proyecto:** Web de la academia musical Vibra Music (Carmona, Sevilla)
**Versión:** 1.0.0
**Fecha:** 3 de noviembre de 2026
**Licencia:** propietaria — © Vibra Music Studio (ver `codigo-fuente/LICENSE`)

---

## 1. Contenido del paquete

| Carpeta | Contenido |
|---|---|
| `memoria/VibraMusic-PMV.pdf` | Memoria del PMV (documento para imprimir/archivar). |
| `memoria/memoria.md` | Fuente de la memoria en Markdown. |
| `memoria/memoria.html` | Fuente con estilos (permite reexportar el PDF). |
| `codigo-fuente/` | Código completo de la aplicación (Angular + Supabase). |

El código fuente **no** incluye `node_modules`, `dist` ni la carpeta `.git`.

## 2. Accesos

- **Web en producción:** https://vibramusicstudio.es
- **Repositorio:** https://github.com/CharliePl8/vibramusic
- **Correo de contacto:** support@vibramusicstudio.es

## 3. Puesta en marcha (local)

Requisitos: **Node.js 22** y **npm 11**.

```bash
cd codigo-fuente
npm install
npm start
```

La web queda disponible en http://localhost:4200.

Otros comandos:

| Comando | Descripción |
|---|---|
| `npm start` | Servidor de desarrollo. |
| `npm run build` | Build de producción en `dist/`. |
| `npm test` | Tests unitarios (Vitest). |

## 4. Estructura del proyecto

```
codigo-fuente/
├── src/app/
│   ├── core/          # Servicios, modelos, guards y datos
│   ├── features/      # landing, authentication, admin, profile, not-found
│   ├── shared/        # Componentes reutilizables (botones, cards, header...)
│   └── assets/styles/ # Variables, mixins y estilos globales (SCSS)
├── supabase/
│   ├── schema.sql     # Esquema de base de datos (idempotente)
│   └── emails/        # Plantillas HTML de los emails de autenticación
├── public/            # Imágenes y ficheros estáticos
└── scripts/           # Utilidades de build
```

La documentación técnica y de despliegue está en `codigo-fuente/README.md` y en
`supabase/emails/README.md`.

## 5. Servicios utilizados

- **Hosting:** Cloudflare Pages (despliegue continuo desde el repositorio).
- **Backend:** Supabase (autenticación + PostgreSQL con RLS).
- **Correo saliente:** Resend (SMTP propio, remitente `support@vibramusicstudio.es`).
- **Correo entrante:** Cloudflare Email Routing.

Las credenciales y claves **no** se incluyen en este paquete; se gestionan en los
paneles de cada servicio.

## 6. Estado del PMV

- Landing completa, autenticación real, perfil de usuario, reservas de estudio,
  mensajería de contacto y panel de administración.
- Panel de administración con paginación, filtrado de reservas pasadas y borrado
  de mensajes.
- **Contenido pendiente de datos definitivos:** catálogo de cursos/precios,
  imágenes y datos de contacto deben validarse o sustituirse por la información
  real del centro antes del lanzamiento.
- Sin pasarela de pago: las reservas no generan cobro online.

## 7. Soporte

Para dudas o incidencias: **support@vibramusicstudio.es**
